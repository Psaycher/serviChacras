CREATE DATABASE  IF NOT EXISTS `servichacras` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `servichacras`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: servichacras
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` varchar(255) NOT NULL,
  `alta` bit(1) NOT NULL,
  `apellido` varchar(255) DEFAULT NULL,
  `barrio` enum('BARRIO1Ruta2km69','BARRIO2Ruta2km75','BARRIO3Ruta13km86','FORANEO') DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `rol` enum('USER','ADMIN','CLIENTE','PROVEEDOR','MIXTO') DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_5171l57faosmj8myawaucatdw` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES ('00d3eb81-4d58-45dc-82b5-3b5dd2652818',_binary '','Andriani','BARRIO1Ruta2km69','Borques 374','leandroandriani@gmail.com','Leandro','$2a$10$MJWa7A0Dj0raek2czByWGuLgCvgrIGsZHH8lmH6wvhSqkHFENLRja','CLIENTE','1136020666'),('441e7dda-a7e6-4b4c-bb5a-78046e3490cf',_binary '','Cliente1','BARRIO1Ruta2km69','DireCliente1','cliente1@gmail.com','Cliente1','$2a$10$7Te4DRFcsABIYhHvcxHJOe5iD8eDPbZkOqjUqk74eUDZG0kNcks8W','CLIENTE','11365487947'),('4fc54676-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoCliente2','BARRIO1Ruta2km69','manzana13 numero75','cliente2@mail.com','NombreCliente2','cliente2','CLIENTE','2615185866'),('4fc54a88-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoCliente3','BARRIO2Ruta2km75','manzana6 numero33','cliente3@mail.com','NombreCliente3','cliente3','CLIENTE','2614622193'),('4fc632ba-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoCliente4','BARRIO3Ruta13km86','manzana4 numero15','cliente4@mail.com','NombreCliente4','cliente4','CLIENTE','2613569887'),('4fc636ed-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoCliente5','BARRIO2Ruta2km75','manzana16 numero39','cliente5@mail.com','NombreCliente5','cliente5','CLIENTE','2614112139'),('4fc63811-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor2','BARRIO1Ruta2km69','manzana17 numero32','proveedor2@mail.com','NombreProveedor2','proveedor2','PROVEEDOR','2613771212'),('4fc638da-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor3','BARRIO3Ruta13km86','manzana9 numero18','proveedor3@mail.com','NombreProveedor3','proveedor3','PROVEEDOR','2615143249'),('4fc639b5-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor4','BARRIO1Ruta2km69','manzana7 numero44','proveedor4@mail.com','NombreProveedor4','proveedor4','PROVEEDOR','26134653331'),('4fc63a8a-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor5','BARRIO3Ruta13km86','manzana13 numero29','proveedor5@mail.com','NombreProveedor5','proveedor5','PROVEEDOR','2615214574'),('4fc63bbd-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor6','BARRIO1Ruta2km69','manzana1 numero12','proveedor6@mail.com','NombreProveedor6','proveedor6','PROVEEDOR','26156366999'),('4fc63cbc-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor7','BARRIO3Ruta13km86','manzana2 numero23','proveedor7@mail.com','NombreProveedor7','proveedor7','PROVEEDOR','26178912345'),('4fc63dc9-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor8','BARRIO1Ruta2km69','manzana3 numero34','proveedor8@mail.com','NombreProveedor8','proveedor8','PROVEEDOR','26145678901'),('4fc63ed1-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor9','BARRIO3Ruta13km86','manzana4 numero45','proveedor9@mail.com','NombreProveedor9','proveedor9','PROVEEDOR','26132165498'),('4fc63f68-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor10','BARRIO2Ruta2km75','manzana5 numero56','proveedor10@mail.com','NombreProveedor10','proveedor10','PROVEEDOR','26198765432'),('4fc63fed-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor11','BARRIO2Ruta2km75','manzana6 numero67','proveedor11@mail.com','NombreProveedor11','proveedor11','PROVEEDOR','26112345678'),('4fc6406e-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor12','BARRIO1Ruta2km69','manzana7 numero78','proveedor12@mail.com','NombreProveedor12','proveedor12','PROVEEDOR','26187654321'),('4fc6410f-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor13','BARRIO3Ruta13km86','manzana8 numero89','proveedor13@mail.com','NombreProveedor13','proveedor13','PROVEEDOR','26123456789'),('4fc6419c-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor14','BARRIO1Ruta2km69','manzana9 numero10','proveedor14@mail.com','NombreProveedor14','proveedor14','PROVEEDOR','26134567890'),('4fc64220-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor15','BARRIO2Ruta2km75','manzana10 numero21','proveedor15@mail.com','NombreProveedor15','proveedor15','PROVEEDOR','26145678902'),('4fc6429f-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor16','BARRIO1Ruta2km69','manzana11 numero32','proveedor16@mail.com','NombreProveedor16','proveedor16','PROVEEDOR','26156789012'),('4fc64327-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor17','BARRIO3Ruta13km86','manzana12 numero43','proveedor17@mail.com','NombreProveedor17','proveedor17','PROVEEDOR','26167890123'),('4fc643a4-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor18','BARRIO2Ruta2km75','manzana13 numero54','proveedor18@mail.com','NombreProveedor18','proveedor18','PROVEEDOR','26178901234'),('4fc64420-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor19','BARRIO2Ruta2km75','manzana14 numero65','proveedor19@mail.com','NombreProveedor19','proveedor19','PROVEEDOR','26189012345'),('4fc644a7-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor20','BARRIO1Ruta2km69','manzana15 numero76','proveedor20@mail.com','NombreProveedor20','proveedor20','PROVEEDOR','26190123456'),('4fc64538-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoProveedor21','BARRIO3Ruta13km86','manzana1 numero87','proveedor21@mail.com','NombreProveedor21','proveedor21','PROVEEDOR','26101234567'),('4fc645be-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoMixto1','BARRIO1Ruta2km69','manzana12 numero81','mixto1@mail.com','NombreMixto1','mixto1','MIXTO','2613222396'),('4fc64640-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoMixto2','BARRIO2Ruta2km75','manzana3 numero27','mixto2@mail.com','NombreMixto2','mixto2','MIXTO','261458826'),('4fc646c0-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoUsuario1','BARRIO3Ruta13km86','manzana2 numero16','usuario1@mail.com','Nombrusuario1','usuario1','USER','2615124474'),('4fc64744-3019-11ef-8c57-1c1b0d909694',_binary '','ApellidoUsuario2','BARRIO2Ruta2km75','manzana8 numero44','usuario2@mail.com','Nombrusuario2','usuario2','USER','2614856523'),('56038260-e4bf-4a43-9e83-3f6ba529cd43',_binary '','Cliente3','BARRIO3Ruta13km86','Borques123','Cliente3@gmail.com','Cliente3','$2a$10$V4CjOMJyaIAArc1BuMwO4OBpFrTOEWFZb0e1ZwK3YYrQ5JwjkAcu6','CLIENTE','123144787'),('6176c837-2a9e-434d-a52f-60fa5799c4b7',_binary '','Proveedor2Apellido','BARRIO1Ruta2km69','Calle 123','proveedor2@gmail.com','Proveedor2','$2a$10$cyGaVW6.TAkGY7YgNPT2ru8IJotdSLaCsX9s5O1256Mlh7mHMDAW2','PROVEEDOR','1166447879'),('817f1a41-0609-4afd-817f-366e7af9eacd',_binary '','Andriani','BARRIO1Ruta2km69','Borques 374','leandro@andriani.com','Leandro','$2a$10$w3rSpLD1R8qNiCq3Nv5YCebwolbl9KkLsPd1dYgvpNmRfdnOr583u','CLIENTE','1136020666'),('b7e5f2f1-b7d9-4092-99c5-99f105dc4f9c',_binary '','Andriani','BARRIO1Ruta2km69','Borques 374','leandroeandriani@gmail.com','Leandro','$2a$10$J.dwC9OT/WYl.GBKtw33k.gzOy/vNxYVP4t/K/D.ZdVIHm6G9hoIG','CLIENTE','1136020666'),('dbbd67f8-c005-4a1c-bd36-d67a4232855a',_binary '','ProveedorApellido','BARRIO1Ruta2km69','Domicilio 123','proveedor1@gmail.com','Proveedor1','$2a$10$2ThioLMARyBDcluc3EwYmeX9JNQNyt1u89imp8Q4VIeulTNhIi22.','PROVEEDOR','1133447788');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21 20:27:21
