CREATE DATABASE  IF NOT EXISTS `servichacras` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `servichacras`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: servichacras
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `servicio`
--

DROP TABLE IF EXISTS `servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicio` (
  `id` varchar(255) NOT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_5sp1r1csf8w09psuq7p8fatbs` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicio`
--

LOCK TABLES `servicio` WRITE;
/*!40000 ALTER TABLE `servicio` DISABLE KEYS */;
INSERT INTO `servicio` VALUES ('39f692e3-3018-11ef-8c57-1c1b0d909694','Servicios de limpieza','Servicio de limpieza para interiores de casas y oficinas','Limpieza de interiores'),('39f7209c-3018-11ef-8c57-1c1b0d909694','Servicios de limpieza','Servicio de lavado y planchado de ropa a domicilio','Lavado y planchado de ropa'),('39f76b28-3018-11ef-8c57-1c1b0d909694','Servicios de limpieza','Limpieza profesional de ventanas en edificios y casas','Limpieza de ventanas'),('39f79c24-3018-11ef-8c57-1c1b0d909694','Servicios de limpieza','Servicio completo de limpieza profunda para todas las areas del hogar','Limpieza profunda de la casa'),('39f7d37d-3018-11ef-8c57-1c1b0d909694','Servicios de mantenimiento y reparaciones','Servicios electricos generales, reparaciones e instalaciones','Electricidad'),('39f80dbd-3018-11ef-8c57-1c1b0d909694','Servicios de mantenimiento y reparaciones','Reparaciones y mantenimiento de sistemas de plomeria','Plomeria'),('39f84abf-3018-11ef-8c57-1c1b0d909694','Servicios de mantenimiento y reparaciones','Servicios de carpinteria para construcciones y reparaciones','Carpinteria'),('39f88a8e-3018-11ef-8c57-1c1b0d909694','Servicios de mantenimiento y reparaciones','Mantenimiento y diseno de jardines, paisajismo y botánica','Jardineria y cuidado del jardin'),('39f8c250-3018-11ef-8c57-1c1b0d909694','Servicios de mantenimiento y reparaciones','Servicios de pintura y decoracion de interiores y exteriores, murales personalizados, asesoramiento en arte y fengshui','Pintura y decoracion'),('39f8ff9b-3018-11ef-8c57-1c1b0d909694','Servicios de seguridad','Instalacion y monitoreo de alarmas y camaras de seguridad','Instalacion y monitoreo de sistemas de seguridad'),('39f94185-3018-11ef-8c57-1c1b0d909694','Servicios de seguridad','Servicios de vigilancia privada y patrullaje','Vigilancia y patrullaje'),('39f97961-3018-11ef-8c57-1c1b0d909694','Servicios de seguridad','Atencion y gestion de emergencias en el hogar','Atencion a emergencias'),('39f9aaa2-3018-11ef-8c57-1c1b0d909694','Servicios de tecnologia y conectividad','Instalacion y configuracion de equipos electronicos diversos','Instalacion y configuracion de equipos electronicos'),('39f9e4a0-3018-11ef-8c57-1c1b0d909694','Servicios de tecnologia y conectividad','Soporte tecnico y resolucion de problemas informaticos','Soporte tecnico y solucion de problemas'),('39fa1aae-3018-11ef-8c57-1c1b0d909694','Servicios de tecnologia y conectividad','Instalacion y mantenimiento de servicios de internet y television','Servicios de internet y television'),('39fa6335-3018-11ef-8c57-1c1b0d909694','Servicios de cuidado personal y bienestar','Servicios de cuidado y atencion para mascotas','Cuidado de mascotas'),('39faa2a7-3018-11ef-8c57-1c1b0d909694','Servicios de cuidado personal y bienestar','Servicios de cuidado infantil, a personas mayores y personas con necesidades particulares, ayudantia terapeutica','Cuidado y atención'),('39fadb3f-3018-11ef-8c57-1c1b0d909694','Servicios de cuidado personal y bienestar','Servicios de salud, bienestar, servicios de enfermeria y atencion medica a domicilio','Servicios de salud y bienestar'),('39fb1657-3018-11ef-8c57-1c1b0d909694','Servicios de entrega y logistica','Delivery de alimentos y compras a domicilio','Entrega de comida y compras'),('39fb4e53-3018-11ef-8c57-1c1b0d909694','Servicios de entrega y logistica','Servicios de entrega y mensajeria de paquetes','Entrega de paquetes'),('39fb93e5-3018-11ef-8c57-1c1b0d909694','Servicios de entrega y logistica','Servicios de transporte y mudanzas locales y nacionales','Transporte y mudanzas');
/*!40000 ALTER TABLE `servicio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21 20:27:21
