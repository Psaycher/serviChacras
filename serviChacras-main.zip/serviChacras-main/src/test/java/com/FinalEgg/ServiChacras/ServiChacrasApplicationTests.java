package com.FinalEgg.ServiChacras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiChacrasApplicationTests {

	@Test
	void contextLoads() {
	}

}
