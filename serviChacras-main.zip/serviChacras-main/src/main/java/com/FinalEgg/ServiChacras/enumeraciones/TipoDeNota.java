package com.FinalEgg.ServiChacras.enumeraciones;

public enum TipoDeNota {
    PEDIDOSolicitud,
    PEDIDOAceptado,
    PEDIDORechazado,
    PEDIDOCancelado,
    PEDIDOFinalizado,
    PAGOPendiente,
    PAGODemandado,
    PAGOEfectuado,
    DENUNCIA,
    DENUNCIARechazada,
    PUNTUACION;
}
