package com.FinalEgg.ServiChacras.enumeraciones;

public enum Rol {
    USER,
    ADMIN,
    CLIENTE,
    PROVEEDOR,
    MIXTO,
}