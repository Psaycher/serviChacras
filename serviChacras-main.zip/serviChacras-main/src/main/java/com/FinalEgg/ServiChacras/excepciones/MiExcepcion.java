package com.FinalEgg.ServiChacras.excepciones;

public class MiExcepcion extends Exception{
    public MiExcepcion (String msj) { super(msj); }
}