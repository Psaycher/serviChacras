package com.FinalEgg.ServiChacras.enumeraciones;

public enum Estado {
    PENDIENTE,
    EFECTUADO;
}
